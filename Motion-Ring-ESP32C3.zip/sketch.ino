#include <Wire.h>
#include <string.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SDA_PIN 8
#define SCL_PIN 9
#define BTN_PIN 3
#define MPU_ADDR 0x68
#define OLED_ADDR 0x3C

const bool DEBUG = false;
const float ZERO_TOL = 0.05;
const int STABLE_COUNT = 5;
const unsigned long LONG_MS = 800;
const unsigned long DOUBLE_MS = 350;
const unsigned long DEBOUNCE_MS = 30;

Adafruit_SSD1306 display(128, 64, &Wire, -1);

const char* candidate = "CENTER";
const char* lastDir = "CENTER";
int candidateCount = 0;

bool wasPressed = false;
bool longFired = false;
int clickCount = 0;
unsigned long pressStart = 0;
unsigned long lastEdge = 0;
unsigned long lastRelease = 0;

bool readAccel(float &ax, float &ay) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(MPU_ADDR, 4) != 4) return false;
  uint8_t b[4];
  for (int i = 0; i < 4; i++) {
    b[i] = Wire.read();
  }
  int16_t rx = (int16_t)(((uint16_t)b[0] << 8) | b[1]);
  int16_t ry = (int16_t)(((uint16_t)b[2] << 8) | b[3]);
  ax = rx / 16384.0;
  ay = ry / 16384.0;
  return true;
}

void show(const char* text) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("MOTION RING");
  display.setTextSize(2);
  display.setCursor(0, 28);
  display.print(text);
  display.display();
}

const char* getText(float ax, float ay) {
  float absX = fabs(ax);
  float absY = fabs(ay);

  if (absX <= ZERO_TOL && absY <= ZERO_TOL) return "CENTER";

  if (absX >= absY) {
    return ax > 0 ? "RIGHT" : "LEFT";
  }
  return ay > 0 ? "FORWARD" : "BACKWARD";
}

void announce(const char* name) {
  Serial.println(name);
  show(name);
}

void updateDirection() {
  float ax, ay;
  if (!readAccel(ax, ay)) return;

  if (DEBUG) {
    Serial.print("ax=");
    Serial.print(ax);
    Serial.print(" ay=");
    Serial.println(ay);
  }

  const char* text = getText(ax, ay);

  if (strcmp(text, candidate) == 0) {
    if (candidateCount < STABLE_COUNT) candidateCount++;
  } else {
    candidate = text;
    candidateCount = 1;
  }

  if (candidateCount < STABLE_COUNT) return;
  if (strcmp(candidate, lastDir) == 0) return;

  lastDir = candidate;
  announce(lastDir);
}

void handleButton(unsigned long now) {
  bool pressed = (digitalRead(BTN_PIN) == LOW);

  if (pressed && !wasPressed && now - lastEdge > DEBOUNCE_MS) {
    pressStart = now;
    lastEdge = now;
    longFired = false;
  }

  if (pressed && wasPressed && !longFired && now - pressStart >= LONG_MS) {
    announce("LONG PRESS");
    longFired = true;
    clickCount = 0;
  }

  if (!pressed && wasPressed && now - lastEdge > DEBOUNCE_MS) {
    lastEdge = now;
    if (!longFired) {
      clickCount++;
      lastRelease = now;
    }
  }

  if (clickCount > 0 && !pressed && now - lastRelease > DOUBLE_MS) {
    announce(clickCount >= 2 ? "DOUBLE CLICK" : "CLICK");
    clickCount = 0;
  }

  wasPressed = pressed;
}

void setup() {
  Serial.begin(115200);
  pinMode(BTN_PIN, INPUT_PULLUP);
  Wire.begin(SDA_PIN, SCL_PIN);

  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);
  Wire.write(0x00);
  Wire.endTransmission();

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("OLED not found");
  }

  show("CENTER");
  Serial.println("Motion Ring ready");
}

void loop() {
  unsigned long now = millis();

  updateDirection();
  handleButton(now);

  delay(20) ;
}